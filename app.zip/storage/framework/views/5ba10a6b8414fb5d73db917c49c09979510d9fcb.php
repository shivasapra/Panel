<?php $__env->startSection('css'); ?>
    <style>
        .institute_html {
            background-color: #fff;
            box-shadow: 0px 0px 5px rgba(0,0,0,0.1);
        }
        .institute_html option {
            border-bottom: 1px solid #f4f4f4;
            padding: 7px 15px;
        }
        .institute_html option:hover{
            cursor: pointer;
            background-color:#54458b;
            color:#fff;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-tabs card-header-info">
                            <div class="nav-tabs-navigation">
                                <div class="nav-tabs-wrapper">
                                    <ul class="nav nav-tabs" data-tabs="tabs">
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($active== 'registration' ? ' active' : ''); ?>" href="#registration" data-toggle="tab">
                                                <i class="material-icons">account_box</i> Registration
                                                <div class="ripple-container"></div>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($active== 'accomodation' ? ' active' : ''); ?>" href="#accomodation" data-toggle="tab">
                                                <i class="material-icons">store</i> Accomodation
                                                <div class="ripple-container"></div>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($active== 'conference' ? ' active' : ''); ?>" href="#conference" data-toggle="tab">
                                                <i class="material-icons">stars</i> Post-Conference Workshop
                                                <div class="ripple-container"></div>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($active== 'payment' ? ' active' : ''); ?>" href="#payment" data-toggle="tab">
                                                <i class="material-icons">account_balance</i> Payment
                                                <div class="ripple-container"></div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-md-10">
                                <div class="card-body">
                                    <?php if(session('status')): ?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="tab-content">
                                        <div class="tab-pane <?php echo e($active== 'registration' ? ' active' : ''); ?>" id="registration">
                                            <form action="<?php echo e(route('registration.store',$user)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Name')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name',$user->name)); ?>" required="true" aria-required="true"/>
                                                                    <?php if($errors->has('name')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Email')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                                                <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email',$user->email)); ?>" required />
                                                                <?php if($errors->has('email')): ?>
                                                                    <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                                                                <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Gender')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('gender') ? ' has-danger' : ''); ?>">
                                                                    <select name="gender" class="form-control" style="color:black" required>
                                                                        <option value="">Select Gender</option>
                                                                        <option value="Male" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Male')? 'selected': ' '); ?> <?php endif; ?>>Male</option>
                                                                        <option value="Female" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Female')? 'selected': ' '); ?> <?php endif; ?>>Female</option>
                                                                        <option value="Transgender" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Other')? 'selected': ' '); ?> <?php endif; ?>>Other</option>
                                                                    </select>
                                                                    <?php if($errors->has('gender')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('gender')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Institue Name')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('institue') ? ' has-danger' : ''); ?>">
                                                                    <div class="dropdown">	<div id="myDropdown" class="dropdown-content">
                                                                    <input class="form-control<?php echo e($errors->has('institue') ? ' is-invalid' : ''); ?> institute-name" onkeyup="InstituteDataExtract(this)" name="institute" id="myInput" type="text" placeholder="<?php echo e(__('Institue Name')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->institute); ?>"   <?php else: ?> value="<?php echo e(old('institue')); ?>" <?php endif; ?>  required="true" aria-required="true"/>
                                                                    <div class="institute_html"></div></div></div>
                                                                    <?php if($errors->has('institute')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('institute')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Department')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('department') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" id="input-department" type="text" placeholder="<?php echo e(__('Department')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->department); ?>"   <?php else: ?> value="<?php echo e(old('department')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('department')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('department')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Address')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" id="input-address" type="text" placeholder="<?php echo e(__('Address')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->address); ?>"   <?php else: ?> value="<?php echo e(old('address')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('address')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('address')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Phone')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" minlength="10" maxlength="10" name="phone" id="input-phone" type="text" placeholder="<?php echo e(__('Phone (Without Country Code)')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->phone); ?>"   <?php else: ?> value="<?php echo e(old('phone')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('phone')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('phone')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Category')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('category') ? ' has-danger' : ''); ?>">
                                                                    <select name="category" class="form-control" style="color:black" required id="input-category" <?php if($active != 'registration'): ?> disabled <?php endif; ?>>
                                                                        <option value="">Select Category</option>
                                                                        <option value="Student/Post Doc" <?php if($user->details != null): ?> <?php echo e(($user->details->category == 'Student/Post Doc')? 'selected': ' '); ?> <?php endif; ?>>Student/Post Doc</option>
                                                                        <option value="Faculty" <?php if($user->details != null): ?> <?php echo e(($user->details->category == 'Faculty')? 'selected': ' '); ?> <?php endif; ?>>Faculty</option>
                                                                    </select>                                                      
                                                                    <?php if($errors->has('accompanied_person')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('category')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row input-accompanied_person_div">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Accompanied Person (Non Atendee Of The Conference)')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group<?php echo e($errors->has('accompanied_person') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('accompanied_person') ? ' is-invalid' : ''); ?>" <?php if($active != 'registration'): ?> readonly <?php endif; ?> name="accompanied_person" id="input-accompanied_person" type="number" <?php if($user->details != null): ?>  value="<?php echo e($user->details->accompanied_person); ?>"   <?php else: ?> value="0" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('accompanied_person')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('accompanied_person')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row registration_fee_div">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Registration Fee')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group">
                                                                    <input type="text" name="registration_fee" id="registration_fee" readonly  class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->registration_fee); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row accompanied_person_fee_div">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Accompanied Person Fee')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group">
                                                                    <input type="text" name="accompanied_person_fee" id="accompanied_person_fee" readonly class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->accompanied_person_fee); ?>"  <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"><?php echo e(__('Total Registration Fee')); ?></label>
                                                            <div class="col-sm-9">
                                                                <div class="form-group">
                                                                    <input type="text" name="total_registration_fee" id="total_registration_fee" readonly class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->total_registration_fee); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>
                                                <?php if(!Auth::user()->admin): ?>
                                                    <?php if($user->details != null): ?>
                                                        <div class="text-center">
                                                            <?php if(!$user->details->approved): ?>
                                                                <button type="submit" class="btn btn-md btn-info" <?php if($active != 'registration'): ?> style="display:none;" <?php endif; ?>>Save & Next</button>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="text-center">
                                                            <button type="submit" class="btn btn-md btn-info" <?php if($active != 'registration'): ?> style="display:none;" <?php endif; ?>>Save & Next</button>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($user->details != null): ?>
                                                        <div class="text-center">
                                                            <?php if(!$user->details->approved): ?>
                                                                <a href="<?php echo e(route('approve.registration',$user->details)); ?>" class="btn btn-md btn-success">Approve</a>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </form> 
                                        </div>
                                        <div class="tab-pane <?php echo e($active== 'accomodation' ? ' active' : ''); ?>" id="accomodation">
                                            <form action="<?php echo e(route('accomodation.store',$user)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <?php if($user->accomodation == null): ?>
                                                            <div class="row">
                                                                <label class="col-sm-4 col-form-label"><?php echo e(__('Do You Want Accomodation?')); ?></label>
                                                                <div class="col-sm-8">
                                                                    <input type="radio" id="yes" name="accomodation" value="yes" >Yes
                                                                    <input type="radio" id="no" name="accomodation" value="no" checked>No
                                                                </div>
                                                            </div><hr>
                                                        <?php endif; ?>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Category')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group<?php echo e($errors->has('category') ? ' has-danger' : ''); ?>">
                                                                    <select name="category_acc" class="form-control toggle" style="color:black" disabled required id="category_acc" <?php if($active != 'accomodation'): ?> disabled <?php endif; ?>>
                                                                        <option value="">Select Category</option>
                                                                        <option value="Student/Post Doc" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Student/Post Doc')? 'selected': ' '); ?> <?php endif; ?>>Student/Post Doc</option>
                                                                        <option value="Faculty" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Faculty')? 'selected': ' '); ?> <?php endif; ?>>Faculty</option>
                                                                    </select>
                                                                    <?php if($errors->has('accompanied_person')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('category')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Accomodation For')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="number" class="form-control toggle" name="accomodation_for" id="accomodation_for" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_for); ?>"   <?php else: ?> disabled value="<?php echo e(old('accomodation_for')); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Accomodation Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="number" class="form-control" readonly name="accomodation_charges" id="accomodation_charges" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_charges); ?>"   <?php else: ?> readonly value="<?php echo e(old('accomodation_charges')); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php if(!Auth::user()->admin): ?>
                                                    <?php if($user->accomodation != null): ?>
                                                        <div class="text-center">
                                                            <?php if(!$user->accomodation->approved): ?>
                                                                <button type="submit" <?php if($active != 'accomodation'): ?> style="display:none;" <?php endif; ?> class="btn btn-md btn-info">Save & Next</button>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="text-center">
                                                            <button type="submit" <?php if($active != 'accomodation'): ?> style="display:none;" <?php endif; ?> class="btn btn-md btn-info">Save & Next</button>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($user->accomodation != null): ?>
                                                        <div class="text-center">
                                                            <?php if(!$user->accomodation->approved): ?>
                                                                <a href="<?php echo e(route('approve.accomodation',$user->accomodation)); ?>" class="btn btn-md btn-success">Approve</a>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                            </form>
                                        </div>
                                        <div class="tab-pane <?php echo e($active== 'conference' ? ' active' : ''); ?>" id="conference">
                                            <form action="<?php echo e(route('conference.store',$user)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Introduction')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.   
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Conference Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="number" class="form-control toggle" name="conference_amount" id="conference_amount" <?php if($user->conference != null): ?>  value="<?php echo e($user->conference->conference_amount); ?>"   <?php else: ?> value="<?php echo e(App\Settings::first()->conference_amount); ?>" <?php endif; ?> readonly>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php if($user->conference == null): ?>
                                                            <div class="row">
                                                                <label class="col-sm-4 col-form-label"><?php echo e(__('Do You Want To Attend Post Conference Workshop?')); ?></label>
                                                                <div class="col-sm-8">
                                                                    <input type="radio" id="yes_conference" name="conference" value="yes" >Yes
                                                                    <input type="radio" id="no_conference"  name="conference" value="no" checked>No
                                                                </div>
                                                            </div>
                                                        <?php else: ?>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label" ><b><?php echo e(__('Why You Want To Attend Workshop?')); ?></b></label><br>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <p><?php if($user->conference != null): ?> <?php echo e($user->conference->reason); ?><?php endif; ?></p>            
                                                                </div>
                                                            </div>
                                                        </div>  
                                                        <?php endif; ?>
                                                        <div class="row" id="con" style="display:none;">
                                                            <label class="col-sm-4 col-form-label" ><b><?php echo e(__('Why You Want To Attend Workshop?')); ?></b></label><br>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <textarea name="reason" id="reason"  class="form-control"><?php if($user->conference != null): ?> <?php echo e($user->conference->reason); ?><?php endif; ?></textarea>            
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <?php if(!Auth::user()->admin): ?>
                                                        <button type="submit" class="btn btn-md btn-info" <?php if($active != 'conference'): ?> style="display:none;" <?php endif; ?>>Save & Next</button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="tab-pane <?php echo e($active== 'payment' ? ' active' : ''); ?>" id="payment">
                                            <form action="<?php echo e(route('payment.store',$user)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="row">
                                                            <label class="col-sm-10 col-form-label"><b><?php echo e(__('Deposit The Amount On Below Mentioned Bank Account:')); ?></b></label><br>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Bank')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->bank); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Account Holder Name')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->account_holder_name); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Account No.')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->account_no); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('IFSC Code')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->IFSC); ?>" <?php endif; ?>>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <br><hr>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Registration Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input class="form-control" readonly id="registration_charge" <?php if($user->details != null): ?> value="<?php echo e($user->details->total_registration_fee); ?>" <?php endif; ?> type="text" required="true" aria-required="true"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Accomodation Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input class="form-control" readonly id="accomodation_charge" <?php if($user->accomodation != null): ?> value="<?php echo e($user->accomodation->accomodation_charges); ?>" <?php endif; ?> type="text" required="true" aria-required="true"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Conference Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">
                                                                    <input class="form-control" readonly id="conference_charge" <?php if($user->conference != null): ?> value="<?php echo e($user->conference->conference_amount); ?>" <?php endif; ?> type="text" required="true" aria-required="true"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Total Charges')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" readonly name="amount" id="input-amount" type="text" placeholder="<?php echo e(__('Amount')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->amount); ?>"   <?php else: ?> value="<?php echo e(old('amount')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('amount')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('amount')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Bank Name')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group<?php echo e($errors->has('bank_name') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('bank_name') ? ' is-invalid' : ''); ?>" name="bank_name" id="input-bank_name" type="text" placeholder="<?php echo e(__('Bank Name')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->bank_name); ?>"   <?php else: ?> value="<?php echo e(old('bank_name')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('bank_name')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('bank_name')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Transaction Id:')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group<?php echo e($errors->has('transaction_id') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('transaction_id') ? ' is-invalid' : ''); ?>" name="transaction_id" id="input-transaction_id" type="text" placeholder="<?php echo e(__('Transaction Id')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->transaction_id); ?>"   <?php else: ?> value="<?php echo e(old('transaction_id')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                                                    <?php if($errors->has('transaction_id')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('transaction_id')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-sm-4 col-form-label"><?php echo e(__('Date Of Payment:')); ?></label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group<?php echo e($errors->has('payment_date') ? ' has-danger' : ''); ?>">
                                                                    <input class="form-control<?php echo e($errors->has('payment_date') ? ' is-invalid' : ''); ?>" name="payment_date" id="input-payment_date" type="date" placeholder="<?php echo e(__('Payment Date')); ?>" <?php if($user->details != null and $user->details->payment_date != null): ?>  value="<?php echo e($user->details->payment_date); ?>"   <?php else: ?> value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>" <?php endif; ?>  required="true" aria-required="true"/>
                                                                    <?php if($errors->has('payment_date')): ?>
                                                                    <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('payment_date')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <?php if(!Auth::user()->admin): ?>
                                                        <button type="submit" <?php if($active != 'payment' ): ?> style="display:none;" <?php endif; ?> <?php if($user->details != null): ?> <?php if($user->details->payment_date != null): ?> style="display:none;" <?php endif; ?>  <?php endif; ?> class="btn btn-md btn-info">Submit</button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
            $(document).ready(function() {
            $("#yes").click(function () {
                console.log('shiva');
                
                $('.toggle').removeAttr("disabled");
            });
        
            $("#no").click(function () {
                $('.toggle').attr("disabled",'disabled');
            })

            
        });
    </script>
    <script>
        setInterval(function(){ 
            var category = document.getElementById('category_acc').value;
            
                if (category == 'Student/Post Doc') {
                    $('#accomodation_for').val(1);
                    $('#accomodation_for').attr('readonly','readonly');
                    var accomodation_fee = <?php echo e($accomodation_fee_student); ?>;
                    $('#accomodation_charges').val(accomodation_fee);
                    
                    
                }
                if (category == 'Faculty') {
                    $('#accomodation_for').removeAttr('readonly');
                    var accomodation_for = document.getElementById('accomodation_for').value;
                    var accomodation_fee = <?php echo e($accomodation_fee_faculty); ?>;
                    var accomodation_charges = accomodation_for * accomodation_fee;
                    $('#accomodation_charges').val(accomodation_charges);
                    
                    
                }
                
                if($('#yes_conference').is(':checked')){
                    $('#con').show();
            }
            if($('#no_conference').is(':checked')){
                    $('#con').hide();
            }
        }, 1000);
    </script>
    <script>
        
            setInterval(function(){ 
                var category = document.getElementById('input-category').value;

                    if (category == 'Student/Post Doc') {
                        $('.input-accompanied_person_div').hide();
                        $('#input-accompanied_person').attr('disabled','disabled');
                        $('.accompanied_person_fee_div').hide();
                        $('#accompanied_person_fee').attr('disabled','disabled');
                        $('.registration_fee_div').hide();


                        var registration_fee = <?php echo e($registration_fee_student); ?>;
                        $('#total_registration_fee').val(registration_fee);
                        
                        
                    }
                    if (category == 'Faculty') {
                        $('.input-accompanied_person_div').show();
                        $('#input-accompanied_person').removeAttr('disabled');
                        $('#accompanied_person_fee').removeAttr('disabled');
                        $('.accompanied_person_fee_div').show();
                        $('.registration_fee_div').show();
                        var accompanied_person = document.getElementById('input-accompanied_person').value;
                        var registration_fee = <?php echo e($registration_fee_faculty); ?>;
                        var temp = <?php echo e($accompanied_person_fee_faculty); ?>;
                        var accompanied_person_fee = accompanied_person * (registration_fee - temp) 
                        $('#registration_fee').val(registration_fee);
                        $('#accompanied_person_fee').val(accompanied_person_fee);
                        $('#total_registration_fee').val(registration_fee + accompanied_person_fee);
                        
                    }
                    
                    
            }, 1000);
        
    </script>
    <script>
        setInterval(function(){
            var registration_charge = document.getElementById('registration_charge').value; 
            var accomodation_charge = document.getElementById('accomodation_charge').value;
            var conference_charge = document.getElementById('conference_charge').value;
            $('#input-amount').val(Number(registration_charge) + Number(accomodation_charge) + Number(conference_charge));
        },1000)
    </script>
    <script>
            function InstituteDataExtract(test){
                $value = test.value;
                $.ajax({
                    type : 'get',
                    url : '<?php echo e(URL::to('searchInstitute')); ?>',
                    data:{'search':$value},
                    success:function(data){
                        $(test).next(".institute_html").html(data);
                    }
                });
            }
            function InstituteAssign(temp){
                var div = $(temp).closest(".dropdown-content");
                div.find('.institute-name').val(temp.value);
                $(temp).closest(".institute_html").html('');
            }
        
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Registration Process', 'titlePage' => __('Registration Process')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/process/registration.blade.php ENDPATH**/ ?>