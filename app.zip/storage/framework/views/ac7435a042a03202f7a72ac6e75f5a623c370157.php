<?php $__env->startSection('title'); ?>
Conference Registered Members
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-info">
                <h4 class="card-title "><?php echo e(__('Conference Registered Members ')); ?></h4>
              </div>
              <div class="card-body">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="table-responsive">
                  <table class="table" id="example">
                    <thead class=" text-info">
                      <th>
                          <?php echo e(__('Sno.')); ?>

                      </th>
                      <th>Registration ID</th>
                      <th>
                          <?php echo e(__('Name')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Email')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Gender')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Phone')); ?>

                      </th>
                      <th>
                          <?php echo e(__('Institute')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Department')); ?>

                      </th>
                      <th class="text-right">
                        <?php echo e(__('Actions')); ?>

                      </th>
                    </thead>
                    <tbody>
                      <?php $i =1 ;?>
                      <?php $__currentLoopData = $users->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($user->id != auth()->id() and !$user->admin and Auth::user()->admin): ?>
                        <tr>
                          <th>
                            <?php echo e($i++); ?>.
                          </th>
                          <th>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->registration_id); ?>

                            <?php else: ?>
                              <?php echo e(__('--')); ?>

                            <?php endif; ?>
                          </th>
                          <td>
                            <?php echo e($user->name); ?>

                          </td>
                          <td>
                            <?php echo e($user->email); ?>

                          </td>
                          <td>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->gender); ?>

                            <?php else: ?>
                              <?php echo e('--'); ?>

                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->phone); ?>

                            <?php else: ?>
                              <?php echo e('--'); ?>

                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->institute); ?>

                            <?php else: ?>
                              <?php echo e('--'); ?>

                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->department); ?>

                            <?php else: ?>
                              <?php echo e('--'); ?>

                            <?php endif; ?>
                          </td>
                          <td class="td-actions text-right">
                            <form action="<?php echo e(route('user.destroy', $user)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <?php if($user->details != null): ?>
                                  <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('registration.process', [$user,'registration'])); ?>" data-original-title="" title="">
                                    <i class="material-icons">remove_red_eye</i>
                                    <div class="ripple-container"></div>
                                  </a>
                                <?php endif; ?>
                              </form>
                          </td>
                        </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>


<script>
        $(document).ready(function() {
      $('#example').DataTable( {
          dom: 'Bfrtip',
          buttons: [
          ]
      } );
  } );
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('Conference Registered Members ')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/users/index.blade.php ENDPATH**/ ?>