<div class="sidebar" data-color="azure" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    
    <a href="http://www.iisermohali.ac.in/" class="simple-text logo-normal">
      <img src="<?php echo e(asset('material/img/iisermlogo.jpg')); ?>" style="width:50px;"><br><?php echo e(__('IISER')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      
        
            
            <?php if(Auth::user()->admin): ?>
              <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                    <i class="material-icons">account_circle</i>
                    <p><?php echo e(__('Registered Members ')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Accomodations' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('accomodation.index')); ?>">
                    <i class="material-icons">stars</i>
                    <p><?php echo e(__('Accomodations')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Abstracts' ? ' active' : ''); ?>">
                <?php $array = array();  $sarray = serialize($array)?>
                <a class="nav-link" href="<?php echo e(route('abstract.index',['array'=>1])); ?>">
                    <i class="material-icons">airplay</i>
                    <p><?php echo e(__('Abstracts')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Registration Report' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('regTran')); ?>">
                    <i class="material-icons">description</i>
                    <p><?php echo e(__('Registration Report')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Accomodation Report' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('accTran')); ?>">
                    <i class="material-icons">description</i>
                    <p><?php echo e(__('Accomodation Report')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Abstract Report' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('abstract.report')); ?>">
                    <i class="material-icons">description</i>
                    <p><?php echo e(__('Abstract Report')); ?></p>
                </a>
              </li>
              <li class="nav-item<?php echo e($activePage == 'Settings' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('settings')); ?>">
                    <i class="material-icons">settings</i>
                    <p><?php echo e(__('Settings')); ?></p>
                </a>
              </li>
              
            <?php else: ?>
              <li class="nav-item<?php echo e($activePage == 'Registration Process' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('registration.process',['user'=>Auth::user(),'active'=>'registration'])); ?>">
                    <i class="material-icons">account_circle</i>
                    <p><?php echo e(__('Registration Process')); ?></p>
                </a>
              </li>
              
              <li class=" <?php if(Auth::user()->details != null): ?> <?php if(Auth::user()->details->payment_date == null): ?> li-disable <?php endif; ?> <?php else: ?> li-disable <?php endif; ?> nav-item<?php echo e($activePage == 'Abstract' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('abstract',Auth::user())); ?>" >
                    <i class="material-icons">airplay</i>
                    <p><?php echo e(__('Abstract')); ?></p>
                </a>
              </li>
              
              
            <?php endif; ?>
            <li class="nav-item">
                    <a class="nav-link"  href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <i class="material-icons">power_settings_new</i>
                    <p><?php echo e(__('Logout')); ?></p>
                </a>
              </li>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                  <?php echo csrf_field(); ?>
                </form>
            
          
      
      
      
      
      
      
      
      
    </ul>
  </div>
</div><?php /**PATH C:\xampp\htdocs\IISER\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>