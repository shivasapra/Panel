<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <?php echo method_field('post'); ?>
            <div class="card ">
                <div class="card-header card-header-info">
                    <h4 class="card-title "><?php echo e(__('Feedbacks')); ?></h4>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="row">
                        <div class="col-sm-12">
                            <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <i class="material-icons">close</i>
                            </button>
                            <span><?php echo e(session('status')); ?></span>
                            </div>
                        </div>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-info">
                                <th>
                                    <?php echo e(__('Sno.')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Name')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Email')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('Feedback')); ?>

                                </th>
                            </thead>
                            <tbody>
                                <?php $i =1 ;?>
                                <?php $__currentLoopData = App\Feedback::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th>
                                        <?php echo e($i++); ?>.
                                    </th>
                                    <td>
                                        <?php echo e($feedback->user->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($feedback->user->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($feedback->feedback); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Feedbacks', 'titlePage' => 'Feedbacks'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/feedbacks.blade.php ENDPATH**/ ?>