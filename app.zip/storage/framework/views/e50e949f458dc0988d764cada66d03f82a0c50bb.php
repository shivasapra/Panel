<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      
    </nav>
    <div class="copyright float-right">
        Designed And Developed by
        <a href="https://www.himsoftsolution.com">Him Soft Solution Chandigarh</a>
       </div>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\IISER\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>