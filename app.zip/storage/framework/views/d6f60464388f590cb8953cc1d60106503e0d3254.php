<?php $__env->startSection('css'); ?>
<style>
.institute_html {
    background-color: #fff;
    box-shadow: 0px 0px 5px rgba(0,0,0,0.1);
}
.institute_html option {
    border-bottom: 1px solid #f4f4f4;
    padding: 7px 15px;
}
.institute_html option:hover{
    cursor: pointer;
    background-color:#54458b;
    color:#fff;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php if($user->details != null): ?><?php echo e(route('edit.register',[$user,$user->details])); ?><?php else: ?> <?php echo e(route('registerr',$user)); ?><?php endif; ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="card ">
              <div class="card-header card-header-info">
                <h4 class="card-title"><?php echo e(__('Details')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body ">
                    <?php if(session('status')): ?>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="alert alert-success">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="material-icons">close</i>
                          </button>
                          <span><?php echo e(session('status')); ?></span>
                        </div>
                      </div>
                    </div>
                  <?php endif; ?>
                
                <div class="row">
                <div class="col-md-9">
                <?php if($user->details != null): ?>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Registration ID')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <?php echo e($user->details->registration_id); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Name')); ?></label>
                  <div class="col-sm-10">
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name',$user->name)); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('name')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                  <div class="col-sm-10">
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email',$user->email)); ?>" required />
                      <?php if($errors->has('email')): ?>
                        <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Gender')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('gender') ? ' has-danger' : ''); ?>">
                            <select name="gender" class="form-control" style="color:black" required>
                                <option value="">Select Gender</option>
                                <option value="Male" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Male')? 'selected': ' '); ?> <?php endif; ?>>Male</option>
                                <option value="Female" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Female')? 'selected': ' '); ?> <?php endif; ?>>Female</option>
                                <option value="Transgender" <?php if($user->details != null): ?> <?php echo e(($user->details->gender == 'Transgender')? 'selected': ' '); ?> <?php endif; ?>>Transgender</option>
                            </select>
                        
                            <?php if($errors->has('gender')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('gender')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Institue Name')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('institue') ? ' has-danger' : ''); ?>">
                            <div class="dropdown">	<div id="myDropdown" class="dropdown-content">
                            <input class="form-control<?php echo e($errors->has('institue') ? ' is-invalid' : ''); ?> institute-name" onkeyup="InstituteDataExtract(this)" name="institute" id="myInput" type="text" placeholder="<?php echo e(__('Institue Name')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->institute); ?>"   <?php else: ?> value="<?php echo e(old('institue')); ?>" <?php endif; ?>  required="true" aria-required="true"/>
                            <div class="institute_html"></div></div></div>
                            <?php if($errors->has('institute')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('institute')); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Department')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('department') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" id="input-department" type="text" placeholder="<?php echo e(__('Department')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->department); ?>"   <?php else: ?> value="<?php echo e(old('department')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                            <?php if($errors->has('department')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('department')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Address')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" id="input-address" type="text" placeholder="<?php echo e(__('Address')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->address); ?>"   <?php else: ?> value="<?php echo e(old('address')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                            <?php if($errors->has('address')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('address')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Phone')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" id="input-phone" type="text" placeholder="<?php echo e(__('Phone')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->phone); ?>"   <?php else: ?> value="<?php echo e(old('phone')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                            <?php if($errors->has('phone')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Category')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('category') ? ' has-danger' : ''); ?>">
                            <select name="category" class="form-control" style="color:black" required id="input-category">
                                <option value="">Select Category</option>
                                <option value="Student/Post Doc" <?php if($user->details != null): ?> <?php echo e(($user->details->category == 'Student/Post Doc')? 'selected': ' '); ?> <?php endif; ?>>Student/Post Doc</option>
                                <option value="Faculty" <?php if($user->details != null): ?> <?php echo e(($user->details->category == 'Faculty')? 'selected': ' '); ?> <?php endif; ?>>Faculty</option>
                            </select>
                        
                            <?php if($errors->has('accompanied_person')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('category')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Accompanied Person')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group<?php echo e($errors->has('accompanied_person') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('accompanied_person') ? ' is-invalid' : ''); ?>" name="accompanied_person" id="input-accompanied_person" type="number" <?php if($user->details != null): ?>  value="<?php echo e($user->details->accompanied_person); ?>"   <?php else: ?> value="0" <?php endif; ?> required="true" aria-required="true"/>
                            <?php if($errors->has('accompanied_person')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('accompanied_person')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Registration Fee')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group">
                            <input type="text" name="registration_fee" id="registration_fee" readonly  class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->registration_fee); ?>" <?php endif; ?>>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Accompanied Person Fee')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group">
                            <input type="text" name="accompanied_person_fee" id="accompanied_person_fee" readonly class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->accompanied_person_fee); ?>"  <?php endif; ?>>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Total Registration Fee')); ?></label>
                    <div class="col-sm-10">
                        <div class="form-group">
                            <input type="text" name="total_registration_fee" id="total_registration_fee" readonly class="form-control" <?php if($user->details != null): ?>  value="<?php echo e($user->details->total_registration_fee); ?>" <?php endif; ?>>
                        </div>
                    </div>
                </div>
                <div class="row">
                        <label class="col-sm-6 col-form-label"><b><?php echo e(__('Deposit Registration- Charges On Below Mentioned Bank Account:')); ?></b></label><br>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Bank')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->bank); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Account No.')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->account_no); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('IFSC Code')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->IFSC); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                
               
                </div>
                </div>
                </div>
            </div>
            <div class="card ">
                <div class="card-header card-header-warning">
                    <h4 class="card-title"><?php echo e(__('Registration Fee')); ?></h4>
                    <p class="card-category"></p>
                </div>
                <div class="card-body">
                    <div class="row">
                    <div class="col-md-9">
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Bank Name')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('bank_name') ? ' has-danger' : ''); ?>">
                                <input class="form-control<?php echo e($errors->has('bank_name') ? ' is-invalid' : ''); ?>" name="bank_name" id="input-bank_name" type="text" placeholder="<?php echo e(__('Bank Name')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->bank_name); ?>"   <?php else: ?> value="<?php echo e(old('bank_name')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                <?php if($errors->has('bank_name')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('bank_name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Amount')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                <input class="form-control<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" readonly name="amount" id="input-amount" type="text" placeholder="<?php echo e(__('Amount')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->amount); ?>"   <?php else: ?> value="<?php echo e(old('amount')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                <?php if($errors->has('amount')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('amount')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Transaction Id:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('transaction_id') ? ' has-danger' : ''); ?>">
                                <input class="form-control<?php echo e($errors->has('transaction_id') ? ' is-invalid' : ''); ?>" name="transaction_id" id="input-transaction_id" type="text" placeholder="<?php echo e(__('Transaction Id')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->transaction_id); ?>"   <?php else: ?> value="<?php echo e(old('transaction_id')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                <?php if($errors->has('transaction_id')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('transaction_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Date Of Payment:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('payment_date') ? ' has-danger' : ''); ?>">
                                <input class="form-control<?php echo e($errors->has('payment_date') ? ' is-invalid' : ''); ?>" name="payment_date" id="input-payment_date" type="date" placeholder="<?php echo e(__('Payment Date')); ?>" <?php if($user->details != null): ?>  value="<?php echo e($user->details->payment_date); ?>"   <?php else: ?> value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>" <?php endif; ?>  required="true" aria-required="true"/>
                                <?php if($errors->has('payment_date')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('payment_date')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-md-3">
                            <?php if($user->details!= null): ?>
                            <?php if(!$user->details->approved and auth::user()->admin ): ?>
                                
                                    <a href="<?php echo e(route('approve.registration',$user->details)); ?>" style="margin-top:100px;"  class="btn btn-success"><?php echo e(__('Approve')); ?></a>
                                
                            <?php endif; ?>
                            <?php if($user->details->approved ): ?>
                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    </div>
                </div>
                <?php if($user->details != null and $user->details->approved): ?>
                <?php else: ?>
                    <?php if(!Auth::user()->admin): ?>
                        <div class="text-center">
                            <button type="submit" class="btn btn-info" ><?php if($user->details != null): ?> <?php echo e(__('Update')); ?> <?php else: ?><?php echo e(__('Submit')); ?> <?php endif; ?></button>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
          </form>
          <?php if(Auth::user()->admin and $user->accomodation != null ): ?>
            <div class="card ">
                <div class="card-header card-header-success">
                    <h4 class="card-title"><?php echo e(__('Accomodation')); ?></h4>
                    <p class="card-category"></p>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Category')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('category') ? ' has-danger' : ''); ?>">
                                <select name="category" class="form-control" style="color:black" required id="input-category">
                                    <option value="">Select Category</option>
                                    <option value="Student/Post Doc" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Student/Post Doc')? 'selected': ' '); ?> <?php endif; ?>>Student/Post Doc</option>
                                    <option value="Faculty" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Faculty')? 'selected': ' '); ?> <?php endif; ?>>Faculty</option>
                                </select>
                            
                                <?php if($errors->has('accompanied_person')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('category')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Accomodation For')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="number" class="form-control" name="accomodation_for" id="accomodation_for" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_for); ?>"   <?php else: ?> disabled value="<?php echo e(old('accomodation_for')); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Accomodation Charges')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="number" class="form-control" name="accomodation_charges" id="accomodation_charges" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_charges); ?>"   <?php else: ?> disabled value="<?php echo e(old('accomodation_charges')); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                       
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Bank Name')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('bank_name') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('bank_name') ? ' is-invalid' : ''); ?>" name="bank_name" id="input-bank_name" type="text" placeholder="<?php echo e(__('Bank Name')); ?>" <?php if($user->accomodation != null): ?>   value="<?php echo e($user->accomodation->bank_name); ?>"   <?php else: ?> disabled value="<?php echo e(old('bank_name')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('bank_name')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('bank_name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Amount')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                <input class="form-control <?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" name="amount" id="input-amount" type="text" placeholder="<?php echo e(__('Amount')); ?>" readonly <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->amount); ?>"   <?php else: ?>  value="<?php echo e(old('amount')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('amount')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('amount')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Transaction Id:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('transaction_id') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('transaction_id') ? ' is-invalid' : ''); ?>" name="transaction_id" id="input-transaction_id" type="text" placeholder="<?php echo e(__('Transaction Id')); ?>" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->transaction_id); ?>"   <?php else: ?> disabled value="<?php echo e(old('transaction_id')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('transaction_id')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('transaction_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Date Of Payment:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('payment_date') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('payment_date') ? ' is-invalid' : ''); ?>" name="payment_date" id="input-payment_date" type="date" placeholder="<?php echo e(__('Payment Date')); ?>" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->payment_date); ?>"   <?php else: ?> disabled value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                <?php if($errors->has('payment_date')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('payment_date')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if($user->accomodation != null and $user->accomodation->Room_no != null): ?>
                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Room No:')); ?></label>
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <input class="form-control toggle" name="room_no"  type="text" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->Room_no); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Address:')); ?></label>
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <input class="form-control toggle  name="address"  type="text" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->Address); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-3 text-center">
                        <?php if($user->accomodation!= null): ?>
                            <?php if(!$user->accomodation->approved and auth::user()->admin ): ?>
                                <div class="card-footer ml-auto mr-auto">
                                    <a href="<?php echo e(route('approve.accomodation',$user->accomodation)); ?>" style="margin-top:100px;"  class="btn btn-success"><?php echo e(__('Approve')); ?></a>
                                </div>
                            <?php endif; ?>
                            <?php if($user->accomodation->approved ): ?>
                                <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
          <?php endif; ?>
          <?php if($user->abstract != null and Auth::user()->admin): ?>
            <div class="row">
                <?php if($user->abstract->poster != null): ?>
                    <div class="col-md-6">
                        <div class="card ">
                            <div class="card-header card-header-danger">
                                <h4 class="card-title"><?php echo e(__('Abstract For Poster')); ?>

                                    
                                <p class="card-category"></p>
                            </div>
                            <div class="card-body">
                                <iframe src="<?php echo e(asset($user->abstract->poster)); ?>"  frameborder="0" style="width:100%;height:500px;"></iframe>
                            </div>
                            <input type="file" name="poster" id="poster" style="display:none";>
                            <br><p style="font-size:20px;margin-left:25px;"><b>Terms & Conditions:</b></p>
                            <p style="font-size:17px;margin-left:25px;margin-right:10px;">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>
                            <div class="card-footer ml-auto mr-auto">
                                
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($user->abstract->talk != null): ?>
                    <div class="col-md-6">
                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('Abstract For Talk')); ?>

                                    
                                <p class="card-category"></p>
                            </div>
                            <div class="card-body">
                                <iframe src="<?php echo e(asset($user->abstract->talk)); ?>" frameborder="0" style="width:100%;height:500px;"></iframe>
                            </div>
                            <input type="file" name="talk" id="talk" style="display:none";>
                            <br><p style="font-size:20px;margin-left:25px;"><b>Terms & Conditions:</b></p>
                            <p style="font-size:17px;margin-left:25px;margin-right:10px;">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>
                            <div class="card-footer ml-auto mr-auto">
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        window.onload=function(){
            <?php if($user->details != null): ?>
                <?php if(Auth::user()->admin or $user->details->approved): ?>
                    $('input').attr('disabled','disabled');
                    $('select').attr('disabled','disabled');
                    var elements = document.getElementsByTagName('input');
        
                    for (var i = 0, element; element = elements[i++];) {
                        if (element.type === "hidden")
                        element.removeAttribute('disabled');
                        
                    }
                <?php endif; ?>
            <?php endif; ?>
                };
    </script>

    <script>
        <?php if(!Auth::user()->admin and $user->details == null): ?>
            setInterval(function(){ 
                var category = document.getElementById('input-category').value;
                var accompanied_person = document.getElementById('input-accompanied_person').value;
                
                    if (category == 'Student/Post Doc') {
                        var registration_fee = <?php echo e($registration_fee_student); ?>;
                        var temp = <?php echo e($accompanied_person_fee_student); ?>;
                        var accompanied_person_fee = accompanied_person * (registration_fee - temp) 
                        $('#registration_fee').val(registration_fee);
                        $('#accompanied_person_fee').val(accompanied_person_fee);
                        $('#total_registration_fee').val(registration_fee + accompanied_person_fee);
                        $('#input-amount').val(registration_fee + accompanied_person_fee);
                    }
                    if (category == 'Faculty') {
                        var registration_fee = <?php echo e($registration_fee_faculty); ?>;
                        var temp = <?php echo e($accompanied_person_fee_faculty); ?>;
                        var accompanied_person_fee = accompanied_person * (registration_fee - temp) 
                        $('#registration_fee').val(registration_fee);
                        $('#accompanied_person_fee').val(accompanied_person_fee);
                        $('#total_registration_fee').val(registration_fee + accompanied_person_fee);
                        $('#input-amount').val(registration_fee + accompanied_person_fee);
                    }

            }, 1000);
        <?php endif; ?>
    </script>
    <script>
            function InstituteDataExtract(test){
                $value = test.value;
                $.ajax({
                    type : 'get',
                    url : '<?php echo e(URL::to('searchInstitute')); ?>',
                    data:{'search':$value},
                    success:function(data){
                        $(test).next(".institute_html").html(data);
                    }
                });
            }
            function InstituteAssign(temp){
                var div = $(temp).closest(".dropdown-content");
                div.find('.institute-name').val(temp.value);
                $(temp).closest(".institute_html").html('');
            }
        
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Registration', 'titlePage' => __('Registration')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/registration/index.blade.php ENDPATH**/ ?>