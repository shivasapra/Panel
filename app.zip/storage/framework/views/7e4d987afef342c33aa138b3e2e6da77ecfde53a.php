<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-info">
                <h4 class="card-title "><?php echo e(__('Registration Transaction Report')); ?></h4>
              </div>
              <div class="card-body">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="table-responsive">
                  <table class="table" id="example">
                    <thead class=" text-info">
                        <th>
                            <?php echo e(__('Sno.')); ?>

                        </th>
                        <th>Registration ID</th>
                        <th>
                            <?php echo e(__('Name')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Institute')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Bank')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Amount')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Transaction Id')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Payment Date')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Approved')); ?>

                        </th>
                    </thead>
                    <tbody>
                      <?php $i =1 ;?>
                      <?php $__currentLoopData = App\User::where('admin',0)->get()->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($user->details != null): ?>
                        <tr>
                            <th>
                                <?php echo e($i++); ?>.
                            </th>
                            <th>
                              <?php if($user->details != null): ?>
                                <?php echo e($user->details->registration_id); ?>

                              <?php else: ?>
                                <?php echo e(__('--')); ?>

                              <?php endif; ?>
                            </th>
                            <td>
                                <?php echo e($user->name); ?>

                            </td>
                            <td>
                                <?php if($user->details != null): ?>
                                <?php echo e($user->details->institute); ?>

                                <?php else: ?>
                                <?php echo e('--'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->details != null): ?>
                                    <?php echo e($user->details->bank_name); ?>

                                <?php else: ?>
                                    <?php echo e('--'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->details != null): ?>
                                    <?php echo e($user->details->amount); ?>

                                <?php else: ?>
                                    <?php echo e('--'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->details != null): ?>
                                    <?php echo e($user->details->transaction_id); ?>

                                <?php else: ?>
                                    <?php echo e('--'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->details != null): ?>
                                    <?php echo e($user->details->payment_date); ?>

                                <?php else: ?>
                                    <?php echo e('--'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                              <strong>
                                <?php if($user->details->approved): ?>
                                  <span class="text-success">Yes</span>
                                <?php else: ?>
                                  <span class="text-danger">No</span>
                                <?php endif; ?>
                              </strong>
                            </td>
                        </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>


<script>
        $(document).ready(function() {
      $('#example').DataTable( {
          dom: 'Bfrtip',
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5'
          ]
      } );
  } );
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Registration Report', 'titlePage' => __('Registration-Transaction Report')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/reports/regTran.blade.php ENDPATH**/ ?>