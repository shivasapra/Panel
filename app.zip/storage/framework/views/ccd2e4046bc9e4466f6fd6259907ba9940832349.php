<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <form action="<?php echo e(route('student.reg.settings')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-info">
                            <h4 class="card-title "><b>Student/PostDoc:</b> <?php echo e(__('Registration Fee Settings ')); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status_one')); ?></span>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6">
                                DateWise Amount <input type="radio" value="datewise-reg-student" name="reg_type_student" id="reg-datewise-student" <?php if(App\RefeeSet::where('category','Student')->where('fixed_amount',null)->count()>0): ?> checked <?php endif; ?>>
                                Fixed Amount <input type="radio" value="fixed-reg-student" name="reg_type_student" id="reg-fixed-student"  <?php if(App\RefeeSet::where('category','Student')->where('fixed_amount','!=',null)->count()>0): ?> checked <?php endif; ?>>
                                </div>
                            </div><br>
                            <div id="datewise-reg-student" class="div" <?php if(App\RefeeSet::where('category','Student')->where('fixed_amount',null)->count()>0): ?> style="" <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="reg_from_student">From:</label>
                                        <input type="Date" class="form-control" name="reg_from_student" <?php if($reg_type_student != null): ?>value="<?php echo e($reg_type_student->from); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_to_student">To:</label>
                                        <input type="Date" class="form-control" name="reg_to_student" <?php if($reg_type_student != null): ?>value="<?php echo e($reg_type_student->to); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_valid_amount_student">Charges:</label>
                                        <input type="text" class="form-control" name="reg_valid_amount_student" <?php if($reg_type_student != null): ?>value="<?php echo e($reg_type_student->valid_amount); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_invalid_amount_student">Late Fee Charges:</label>
                                        <input type="text" class="form-control" name="reg_invalid_amount_student" <?php if($reg_type_student != null): ?>value="<?php echo e($reg_type_student->invalid_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                                <br>
                                
                            </div>
                            <br>
                            <div id="fixed-reg-student" class="div" <?php if(App\RefeeSet::where('category','Student')->where('fixed_amount','!=',null)->count()>0): ?> style="" <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="reg_fixed_amount_student">Fixed Amount:</label>
                                        <input type="text" class="form-control" name="reg_fixed_amount_student" <?php if($reg_type_student != null): ?>value="<?php echo e($reg_type_student->fixed_amount); ?>"<?php endif; ?>>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <button type="submit" class="btn btn-sm btn-danger">Save</button>
                        </div>
                    </form>
                </div>

                <div class="card">
                    <form action="<?php echo e(route('faculty.reg.settings')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-info">
                            <h4 class="card-title "><b>Faculty:</b> <?php echo e(__('Registration Fee Settings ')); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status_two')); ?></span>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6">
                                    DateWise Amount <input type="radio" value="datewise-reg-faculty" name="reg_type_faculty" id="reg-datewise-faculty" <?php if(App\RefeeSet::where('category','Faculty')->where('fixed_amount',null)->count()>0): ?> checked <?php endif; ?>>
                                    Fixed Amount <input type="radio" value="fixed-reg-faculty" name="reg_type_faculty" id="reg-fixed-faculty" <?php if(App\RefeeSet::where('category','Faculty')->where('fixed_amount','!=',null)->count()>0): ?> checked <?php endif; ?>>
                                </div>
                            </div><br>
                            <div id="datewise-reg-faculty" class="div_three" <?php if(App\RefeeSet::where('category','Faculty')->where('fixed_amount',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="reg_from_faculty">From:</label>
                                        <input type="Date" class="form-control" name="reg_from_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->from); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_to_faculty">To:</label>
                                        <input type="Date" class="form-control" name="reg_to_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->to); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_valid_amount_faculty">Charges:</label>
                                        <input type="text" class="form-control" name="reg_valid_amount_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->valid_amount); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="reg_invalid_amount_faculty">Late Fee Charges:</label>
                                        <input type="text" class="form-control" name="reg_invalid_amount_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->invalid_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="reg_accompanied_person_amount_faculty">Accompanied Person Amount To Be Deducted:</label>
                                        <input type="text" class="form-control" name="reg_accompanied_person_amount_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->accompanied_person_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div id="fixed-reg-faculty" class="div_three" <?php if(App\RefeeSet::where('category','Faculty')->where('fixed_amount','!=',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="reg_fixed_amount_faculty">Fixed Amount:</label>
                                        <input type="text" class="form-control" name="reg_fixed_amount_faculty" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->fixed_amount); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="reg_accompanied_person_amount_faculty_two">Accompanied Person Amount To Be Deducted:</label>
                                        <input type="text" class="form-control" name="reg_accompanied_person_amount_faculty_two" <?php if($reg_type_faculty != null): ?>value="<?php echo e($reg_type_faculty->accompanied_person_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <button type="submit" class="btn btn-sm btn-danger">Save</button>
                        </div>
                    </form>
                </div>

                <div class="card">
                    <form action="<?php echo e(route('student.ac.settings')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-info">
                            <h4 class="card-title "><?php echo e(__('Accomodation Charges For Student/Post Doc ')); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status_three')); ?></span>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6">
                                    DateWise Amount <input type="radio" value="datewise-ac-student" name="ac_type_student" id="ac-datewise-student" <?php if(App\AcfeeSet::where('category','Student')->where('fixed_amount',null)->count()>0): ?> checked <?php endif; ?>>
                                    Fixed Amount <input type="radio" value="fixed-ac-student" name="ac_type_student" id="ac-fixed-student" <?php if(App\AcfeeSet::where('category','Student')->where('fixed_amount','!=',null)->count()>0): ?> checked <?php endif; ?>>
                                </div>
                            </div><br>
                            <div id="datewise-ac-student" class="div_two" <?php if(App\AcfeeSet::where('category','Student')->where('fixed_amount',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="ac_from_student">From:</label>
                                        <input type="Date" class="form-control" name="ac_from_student" <?php if($ac_type_student != null): ?>value="<?php echo e($ac_type_student->from); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_to_student">To:</label>
                                        <input type="Date" class="form-control" name="ac_to_student" <?php if($ac_type_student != null): ?>value="<?php echo e($ac_type_student->to); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_valid_amount_student">Charges:</label>
                                        <input type="text" class="form-control" name="ac_valid_amount_student" <?php if($ac_type_student != null): ?>value="<?php echo e($ac_type_student->valid_amount); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_invalid_amount_student">Late Fee Charges:</label>
                                        <input type="text" class="form-control" name="ac_invalid_amount_student" <?php if($ac_type_student != null): ?>value="<?php echo e($ac_type_student->invalid_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div id="fixed-ac-student" class="div_two" <?php if(App\AcfeeSet::where('category','Student')->where('fixed_amount','!=',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="ac_fixed_amount_student">Fixed Amount:</label>
                                        <input type="text" class="form-control" name="ac_fixed_amount_student" <?php if($ac_type_student != null): ?>value="<?php echo e($ac_type_student->fixed_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <button type="submit" class="btn btn-sm btn-danger">Save</button>
                        </div>
                    </form>
                </div>

                <div class="card">
                    <form action="<?php echo e(route('faculty.ac.settings')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-info">
                            <h4 class="card-title "><?php echo e(__('Accomodation Charges For Faculty')); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status_four')); ?></span>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6">
                                    DateWise Amount <input type="radio" value="datewise-ac-faculty" name="ac_type_faculty" id="ac-datewise-faculty" <?php if(App\AcfeeSet::where('category','Faculty')->where('fixed_amount',null)->count()>0): ?> checked <?php endif; ?>>
                                    Fixed Amount <input type="radio" value="fixed-ac-faculty" name="ac_type_faculty" id="ac-fixed-faculty" <?php if(App\AcfeeSet::where('category','Faculty')->where('fixed_amount','!=',null)->count()>0): ?> checked <?php endif; ?>>
                                </div>
                            </div><br>
                            <div id="datewise-ac-faculty" class="div_four" <?php if(App\AcfeeSet::where('category','Faculty')->where('fixed_amount',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="ac_from_faculty">From:</label>
                                        <input type="Date" class="form-control" name="ac_from_faculty" <?php if($ac_type_faculty != null): ?>value="<?php echo e($ac_type_faculty->from); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_to_faculty">To:</label>
                                        <input type="Date" class="form-control" name="ac_to_faculty" <?php if($ac_type_faculty != null): ?>value="<?php echo e($ac_type_faculty->to); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_valid_amount_faculty">Charges:</label>
                                        <input type="text" class="form-control" name="ac_valid_amount_faculty" <?php if($ac_type_faculty != null): ?>value="<?php echo e($ac_type_faculty->valid_amount); ?>"<?php endif; ?>>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="ac_invalid_amount_faculty">Late Fee Charges:</label>
                                        <input type="text" class="form-control" name="ac_invalid_amount_faculty" <?php if($ac_type_faculty != null): ?>value="<?php echo e($ac_type_faculty->invalid_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div id="fixed-ac-faculty" class="div_four" <?php if(App\AcfeeSet::where('category','Faculty')->where('fixed_amount','!=',null)->count()>0): ?> style=" " <?php else: ?> style="display:none;" <?php endif; ?>>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="ac_fixed_amount_faculty">Fixed Amount:</label>
                                        <input type="text" class="form-control" name="ac_fixed_amount_faculty" <?php if($ac_type_faculty != null): ?>value="<?php echo e($ac_type_faculty->fixed_amount); ?>"<?php endif; ?>>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <button type="submit" class="btn btn-sm btn-danger">Save</button>
                        </div>
                    </form>
                </div>

                <div class="card">
                    <form action="<?php echo e(route('settings.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-info">
                            <h4 class="card-title "><?php echo e(__('Bank Details & Abstract')); ?></h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Bank Name')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" name="bank" id="input-bank_name" type="text" placeholder="<?php echo e(__('Bank Name')); ?>" <?php if($settings != null): ?>  value="<?php echo e($settings->bank); ?>"   <?php else: ?> value="<?php echo e(old('bank')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Account No')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" name="account_no" type="text" placeholder="<?php echo e(__('Account No')); ?>" <?php if($settings != null): ?>  value="<?php echo e($settings->account_no); ?>"   <?php else: ?> value="<?php echo e(old('account_no')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Account Holder Name')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" name="account_holder_name" type="text" placeholder="<?php echo e(__('Account Holder Name')); ?>" <?php if($settings != null): ?>  value="<?php echo e($settings->account_holder_name); ?>"   <?php else: ?> value="<?php echo e(old('account_holder_name')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('IFSC Code')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" name="IFSC" type="text" placeholder="<?php echo e(__('IFSC Code')); ?>" <?php if($settings != null): ?>  value="<?php echo e($settings->IFSC); ?>"   <?php else: ?> value="<?php echo e(old('IFSC')); ?>" <?php endif; ?> required="true" aria-required="true"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Abstract')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" type="file" name="abstract" accept=".doc,.docx"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Conference Amount')); ?></label>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <input class="form-control" type="text" <?php if($settings != null): ?>  value="<?php echo e($settings->conference_amount); ?>"   <?php else: ?> value="<?php echo e(old('conference_amount')); ?>" <?php endif; ?> name="conference_amount" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-sm btn-info">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>     
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        // console.log(inputValue);
        
        if (inputValue == 'datewise-reg-student' || inputValue == 'fixed-reg-student') {
            var targetDiv = $("#" + inputValue);
            $(".div").not(targetDiv).hide();
            $(targetDiv).show();
        }
    });
});
</script>

<script>
        $(document).ready(function(){
        $('input[type="radio"]').click(function(){
            var inputValue = $(this).attr("value");
            // console.log(inputValue);
            
            if (inputValue == 'datewise-reg-faculty' || inputValue == 'fixed-reg-faculty') {
                var targetDiv = $("#" + inputValue);
                $(".div_three").not(targetDiv).hide();
                $(targetDiv).show();
            }
        });
    });
</script>

<script>
    $(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        if (inputValue == 'datewise-ac-student' || inputValue == 'fixed-ac-student') {
            var targetDiv = $("#" + inputValue);
            $(".div_two").not(targetDiv).hide();
            $(targetDiv).show();
        }
    });
});
</script>

<script>
    $(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        if (inputValue == 'datewise-ac-faculty' || inputValue == 'fixed-ac-faculty') {
            var targetDiv = $("#" + inputValue);
            $(".div_four").not(targetDiv).hide();
            $(targetDiv).show();
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Settings', 'titlePage' => __('Settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/settings.blade.php ENDPATH**/ ?>