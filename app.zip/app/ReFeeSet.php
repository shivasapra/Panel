<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReFeeSet extends Model
{
    protected $table = 're_fee_sets';
}
