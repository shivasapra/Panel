<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institues extends Model
{
    protected $table = 'institues';
}
