<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <?php if(Auth::user()->admin): ?>
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-header card-header-warning card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">account_box</i>
                </div>
                <p class="card-category">Total Conference Registered Members </p>
                <h3 class="card-title"><?php echo e(App\User::where('admin',0)->get()->count()); ?>

                </h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                  <i class="material-icons text-info">remove_red_eye</i>
                  <a href="<?php echo e(route('user.index')); ?>"><span  class="text-info"><b> View</b></span></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">stars</i>
                </div>
                <p class="card-category">Approved Accomodations</p>
                <h3 class="card-title"><?php echo e(App\Accomodation::where('approved',1)->get()->count()); ?>/<?php echo e(App\Accomodation::all()->count()); ?></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-info">remove_red_eye</i>
                    <a href="<?php echo e(route('accomodation.index')); ?>"><span  class="text-info"><b> View</b></span></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">airplay</i>
                </div>
                <p class="card-category">Abstract For Talk</p>
                <h3 class="card-title"><?php echo e(App\Abtract::where('talk','!=',null)->get()->count()); ?></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-info">remove_red_eye</i>
                    <a href="<?php echo e(route('abstract.index',['array'=>1])); ?>"><span  class="text-info"><b> View</b></span></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-header card-header-info card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">airplay</i>
                </div>
                <p class="card-category">Abstract For Poster</p>
                <h3 class="card-title"><?php echo e(App\Abtract::where('poster','!=',null)->get()->count()); ?></h3>
              </div>
              <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-info">remove_red_eye</i>
                    <a href="<?php echo e(route('abstract.index',['array'=>1])); ?>"><span  class="text-info"><b> View</b></span></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        
        <div class="row">
          <div class="col-lg-6 col-md-12">
            <div class="card">
              <div class="card-header card-header-tabs card-header-success">
                <div class="nav-tabs-navigation">
                  <div class="nav-tabs-wrapper">
                    <span class="nav-tabs-title">Accomodations:</span>
                    <ul class="nav nav-tabs" data-tabs="tabs">
                      <li class="nav-item">
                        <a class="nav-link active" href="#approved" data-toggle="tab">
                          <i class="material-icons">done</i> Approved
                          <div class="ripple-container"></div>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#not_approved" data-toggle="tab">
                          <i class="material-icons">highlight_off</i> Not Approved
                          <div class="ripple-container"></div>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#all" data-toggle="tab">
                          <i class="material-icons">stars</i> All
                          <div class="ripple-container"></div>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="approved">
                    <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-success">
                            <th>Registration ID</th>                               
                            <th>Name</th>
                            <th>No Of Persons</th>
                            <th>Charges</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = App\Accomodation::where('approved',1)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th>
                                  <?php if($accomodation->user->details != null): ?>
                                    <?php echo e($accomodation->user->details->registration_id); ?>

                                  <?php else: ?>
                                    <?php echo e(__('--')); ?>

                                  <?php endif; ?>
                                </th>                          
                                <td><?php echo e($accomodation->user->name); ?></td>
                                <td><?php echo e($accomodation->accomodation_for); ?></td>
                                <td><?php echo e($accomodation->accomodation_charges); ?></td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    </div>
                  </div>
                  <div class="tab-pane" id="not_approved">
                    <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-success">
                            <th>Registration ID</th>      
                            <th>Name</th>
                            <th>No Of Persons</th>
                            <th>Charges</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = App\Accomodation::where('approved',0)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th>
                                  <?php if($accomodation->user->details != null): ?>
                                    <?php echo e($accomodation->user->details->registration_id); ?>

                                  <?php else: ?>
                                    <?php echo e(__('--')); ?>

                                  <?php endif; ?>
                                </th>  
                                <td><?php echo e($accomodation->user->name); ?></td>
                                <td><?php echo e($accomodation->accomodation_for); ?></td>
                                <td><?php echo e($accomodation->accomodation_charges); ?></td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    </div>
                  </div>
                  <div class="tab-pane " id="all">
                    <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-success">
                            <th>Registration ID</th>      
                            <th>Name</th>
                            <th>No Of Persons</th>
                            <th>Charges</th>
                            <th>Status</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = App\Accomodation::take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th>
                                  <?php if($accomodation->user->details != null): ?>
                                    <?php echo e($accomodation->user->details->registration_id); ?>

                                  <?php else: ?>
                                    <?php echo e(__('--')); ?>

                                  <?php endif; ?>
                                </th>
                                <td><?php echo e($accomodation->user->name); ?></td>
                                <td><?php echo e($accomodation->accomodation_for); ?></td>
                                <td><?php echo e($accomodation->accomodation_charges); ?></td>
                                <td>
                                  <?php if($accomodation->approved): ?>
                                    <span class="text-success"><b>Approved</b></span>
                                  <?php else: ?>
                                    <span class="text-danger"><b>Not Approved</b></span>
                                  <?php endif; ?>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12">
            <div class="card">
              <div class="card-header card-header-tabs card-header-danger">
                <div class="nav-tabs-navigation">
                  <div class="nav-tabs-wrapper">
                    <span class="nav-tabs-title">Abstracts:</span>
                    <ul class="nav nav-tabs" data-tabs="tabs">
                      <li class="nav-item">
                        <a class="nav-link active" href="#talk" data-toggle="tab">
                          <i class="material-icons">airplay</i> For Talk
                          <div class="ripple-container"></div>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#poster" data-toggle="tab">
                          <i class="material-icons">airplay</i> For Poster
                          <div class="ripple-container"></div>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="talk">
                    <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-danger">
                            <th>Registration ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>View</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = App\Abtract::where('talk','!=',null)->orWhere('same','!=',null)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abstract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th>
                                  <?php if($abstract->user->details != null): ?>
                                    <?php echo e($abstract->user->details->registration_id); ?>

                                  <?php else: ?>
                                    <?php echo e(__('--')); ?>

                                  <?php endif; ?>
                                </th>
                                <td><?php echo e($abstract->user->name); ?></td>
                                <td><?php echo e($abstract->user->email); ?></td>
                                <td class="td_talk">
                                    <input type="text" class="ab_id" value="<?php echo e($abstract->id); ?>" hidden>
                                    <button type="button" onclick="talk(this);" class="btn-btn sm btn-info">View</button>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    </div>
                  </div>
                  <div class="tab-pane" id="poster">
                    <div class="table-responsive">
                        <table class="table">
                          <thead class=" text-danger">
                            <th>Registration ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>View</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = App\Abtract::where('poster','!=',null)->orWhere('same','!=',null)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abstract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th>
                                  <?php if($abstract->user->details != null): ?>
                                    <?php echo e($abstract->user->details->registration_id); ?>

                                  <?php else: ?>
                                    <?php echo e(__('--')); ?>

                                  <?php endif; ?>
                                </th>
                                <td><?php echo e($abstract->user->name); ?></td>
                                <td><?php echo e($abstract->user->email); ?></td>
                                <td class="td_poster">
                                    <input type="text" class="ab_id" value="<?php echo e($abstract->id); ?>" hidden>
                                    <button type="button" onclick="poster(this);" class="btn-btn sm btn-info">View</button>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-warning">
                <h4 class="card-title">Members Stats</h4>
                <p class="card-category">Recent  Members</p>
              </div>
              <div class="card-body table-responsive">
                <table class="table table-hover">
                  <thead class="text-warning">
                    <th>Registration ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Institute</th>
                    <th>Department</th>
                    <th class="td-actions text-right">Action</th>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = App\User::where('admin',0)->orderBy('id','desc')->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th>
                          <?php if($user->details != null): ?>
                            <?php echo e($user->details->registration_id); ?>

                          <?php else: ?>
                            <?php echo e(__('--')); ?>

                          <?php endif; ?>
                        </th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if($user->details != null): ?>
                              <?php echo e($user->details->gender); ?>

                            <?php else: ?>
                              <?php echo e('--'); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                          <?php if($user->details != null): ?>
                            <?php echo e($user->details->phone); ?>

                          <?php else: ?>
                            <?php echo e('--'); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($user->details != null): ?>
                            <?php echo e($user->details->institute); ?>

                          <?php else: ?>
                            <?php echo e('--'); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($user->details != null): ?>
                            <?php echo e($user->details->department); ?>

                          <?php else: ?>
                            <?php echo e('--'); ?>

                          <?php endif; ?>
                        </td>
                        <td class="td-actions text-right">
                          <form action="<?php echo e(route('user.destroy', $user)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <?php if($user->details != null): ?>
                              <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('registration.process',[ $user,'registration'])); ?>" data-original-title="" title="">
                                <i class="material-icons">remove_red_eye</i>
                                <div class="ripple-container"></div>
                              </a>
                            <?php endif; ?>
                              
                          </form>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
      
    </div>
  </div>
<a href="#" id="target2" style="display:none;" data-toggle="modal" data-target="#talk_view"></a>
<a href="#" id="target" style="display:none;" data-toggle="modal" data-target="#poster_view"></a>
<div id="talk-modal"></div>
<div id="poster-modal"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();
    });
  </script>
  <script>
      function talk(temp){
          var i = $(temp).parents('.td_talk').find('.ab_id').val();
          <?php $__currentLoopData = App\Abtract::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var j = <?php echo e($a->id); ?>;
            if (i == j) {
                var data = 
                '<div class="modal fade" id="talk_view">'+
                    '<div class="modal-dialog modal-dialog modal-dialog-centered">'+
                        '<div class="modal-content">'+
            
                            '<!-- Modal Header -->'+
                            '<div class="modal-header">'+
                                '<h4 class="modal-title">Talk Abstract</h4>'+
                                '<button type="button" class="close" data-dismiss="modal">&times;</button>'+
                            '</div>'+
            
                            '<!-- Modal body -->'+
                            '<div class="modal-body">'+
                                '<iframe src="'+
                                '<?php if($a->talk != null): ?>'+
                                    '<?php echo e(asset(explode(".",$a->talk)[0]."html")); ?>'+
                                '<?php else: ?>'+
                                    '<?php echo e(asset(explode(".",$a->same)[0]."html")); ?>'+
                                '<?php endif; ?>"  frameborder="0" style="width:100%;height:500px;"></iframe>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>';
            }
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            
         
	  $('#talk-modal').html(data);
	  $('#target2').click();
          
      }

      function poster(temp){
          var i = $(temp).parents('.td_poster').find('.ab_id').val();
          <?php $__currentLoopData = App\Abtract::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var j = <?php echo e($a->id); ?>;
            if (i == j) {
                var data = 
                '<div class="modal fade" id="poster_view">'+
                    '<div class="modal-dialog modal-dialog modal-dialog-centered">'+
                        '<div class="modal-content">'+
            
                            '<!-- Modal Header -->'+
                            '<div class="modal-header">'+
                                '<h4 class="modal-title">Poster Abstract</h4>'+
                                '<button type="button" class="close" data-dismiss="modal">&times;</button>'+
                            '</div>'+
            
                            '<!-- Modal body -->'+
                            '<div class="modal-body">'+
                                '<iframe src="'+
                                '<?php if($a->poster != null): ?>'+
                                    '<?php echo e(asset(explode(".",$a->poster)[0]."html")); ?>'+
                                '<?php else: ?>'+
                                    '<?php echo e(asset(explode(".",$a->same)[0]."html")); ?>'+
                                '<?php endif; ?>"  frameborder="0" style="width:100%;height:500px;"></iframe>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>';
            }
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            
         
	  $('#poster-modal').html(data);
	  $('#target').click();
          
      }
  </script>

  <script>
      window.onload=function(){
        <?php if(!Auth::user()->admin): ?>
            $('input').attr('disabled','disabled');
            $('select').attr('disabled','disabled');
            var elements = document.getElementsByTagName('input');
    
                for (var i = 0, element; element = elements[i++];) {
                    if (element.type === "hidden")
                    element.removeAttribute('disabled');
                    
                }
            };
        <?php endif; ?>
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/dashboard.blade.php ENDPATH**/ ?>