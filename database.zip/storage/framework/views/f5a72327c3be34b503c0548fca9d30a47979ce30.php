<?php use App\Settings;?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <form action="<?php echo e(route('abstract.submit',$user)); ?>" method="post" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card ">
                        <div class="card-header card-header-info">
                            <h4 class="card-title"><?php echo e(__('Abstract')); ?></h4>
                            <p class="card-category"></p>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-md-10">
                                <div class="card-body">
                                    <?php if(session('status')): ?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="row">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('Subject Area (Closest) :')); ?></label>
                                        <div class="col-sm-5">
                                            <div class="form-group">
                                                <input type="radio" name="subject_area" value="Biophysics/Biochemistry/Molecular Biology (bbmb)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Biophysics/Biochemistry/Molecular Biology (bbmb)"): ?> checked  <?php endif; ?> <?php endif; ?>  required> Biophysics/Biochemistry/Molecular Biology (bbmb) <br>
                                                <input type="radio" name="subject_area" value="Developmental Biology (db)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Developmental Biology (db)"): ?> checked  <?php endif; ?> <?php endif; ?>  required> Developmental Biology (db) <br>
                                                <input type="radio" name="subject_area" value="Neurobiology (nb)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Neurobiology (nb)" ): ?> checked  <?php endif; ?> <?php endif; ?> required> Neurobiology (nb) <br>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <input type="radio" name="subject_area" value="Immunology (im)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Immunology (im)" ): ?> checked  <?php endif; ?> <?php endif; ?> required> Immunology (im) <br>
                                                <input type="radio" name="subject_area" value="Genetics (gen)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Genetics (gen)" ): ?> checked  <?php endif; ?> <?php endif; ?> required> Genetics (gen) <br>
                                                <input type="radio" name="subject_area" value="Evolution (evo)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Evolution (evo)" ): ?> checked  <?php endif; ?> <?php endif; ?> required> Evolution (evo) <br>
                                                <input type="radio" name="subject_area" value="Genetics/Cytogenetics (gc)" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->subject_area == "Genetics/Cytogenetics (gc)" ): ?> checked  <?php endif; ?> <?php endif; ?> required> Genetics/Cytogenetics (gc) <br>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('Presenting Author Name:')); ?></label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" <?php if($user->abstract != null): ?> value="<?php echo e($user->abstract->presenting_author_name); ?>" disabled <?php else: ?> value="<?php echo e($user->name); ?>" <?php endif; ?> name="presenting_author_name" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('Do You Want To Submit Abstract For Poster?')); ?></label>
                                        <div class="col-sm-4">
                                            <input type="radio" name="poster" value="poster_yes" id="poster_yes" onclick="check();" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->poster != null or $user->abstract->same != null ): ?> checked  <?php endif; ?> <?php endif; ?> required> Yes
                                            <input type="radio" name="poster" value="poster_No"  id="poster_no"  onclick="check();" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->poster == null and $user->abstract->same == null ): ?> checked  <?php endif; ?> <?php endif; ?> required> No
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('Do You Want To Submit Abstract For talk?')); ?></label>
                                        <div class="col-sm-4">
                                            <input type="radio" name="talk" value="talk_yes" id="talk_yes" onclick="check();" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->talk != null or $user->abstract->same != null ): ?> checked  <?php endif; ?> <?php endif; ?> required> Yes
                                            <input type="radio" name="talk" value="talk_No"  id="talk_yes" onclick="check();" <?php if($user->abstract != null): ?> disabled <?php if($user->abstract->talk == null and $user->abstract->same == null ): ?> checked  <?php endif; ?> <?php endif; ?> required > No
                                        </div>
                                    </div>
                                    <br>
                                    <?php if($user->abstract != null): ?>
                                        <?php if($user->abstract->same != null): ?>
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label"><?php echo e(__("Do You Want To Submit Same Abstract For Both ?")); ?></label>
                                                <div class="col-sm-4">
                                                    <input type="radio" name="same" value="same_Yes" id="same_yes" onclick="checkSame();" checked disabled  required> Yes
                                                    <input type="radio" name="same" value="same_No" id="same_no" onclick="checkSame();"    disabled required> No
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div id="same"></div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-danger">
                            <b>*Note:- </b>  &nbsp; Upload only preassigned template in <b> &nbsp;doc/docx &nbsp;</b> format only.
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div id="abstract_poster"></div>
                        </div>
                        <div class="col-md-6">
                            <div id="abstract_talk"></div>
                        </div>
                        <div class="col-md-12">
                            <div id="same_abstract"></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($user->abstract == null): ?>
                <div class="text-center">
                    <button class="btn btn-md btn-info" type="submit">Submit</button>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        
        function clickitposter(){
            $('#poster').click();
        }

        function clickittalk(){
            $('#talk').click();
        }

        function clickitsame(){
            $('#same_b').click();
        }
            
        
    </script>

    <script>
        function check(){
            if($('#poster_yes').is(':checked')){
                var poster = 
                    '<div class="card ">'+
                        '<div class="card-header card-header-info">'+
                            '<h4 class="card-title"><?php echo e(__("Abstract For Poster")); ?>'+
                                '<button type="button" id="poster_button" onclick="clickitposter();" <?php if($user->abstract != null): ?> style="display:none;" <?php endif; ?> class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-upload" aria-hidden="true"></i></button>'+
                                '<a href="<?php if($user->abstract != null and $user->abstract->poster != null): ?>'+
                                            '<?php echo e(asset($user->abstract->poster)); ?> '+
                                        '<?php else: ?> '+
                                            '<?php echo e(asset(Settings::first()->abstract)); ?>'+
                                        '<?php endif; ?>" download   class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-download" aria-hidden="true"></i></a>'+
                            '</h4>'+
                            '<p class="card-category"></p>'+
                        '</div>'+
                        '<div class="card-body">'+
                            '<iframe src="'+
                                '<?php if($user->abstract != null and $user->abstract->poster != null): ?>'+
                                    '<?php echo e(asset(explode(".",$user->abstract->poster)[0]."html")); ?>'+
                                '<?php else: ?> '+
                                    '<?php echo e(asset(explode(".",Settings::first()->abstract)[0]."html")); ?>'+
                                '<?php endif; ?>"  frameborder="0" style="width:100%;height:500px;"></iframe>'+
                        '</div>'+
                        '<input type="file" name="poster" accept=".doc,.docx" id="poster" style="display:none";>'+
                    '</div>';
                $('#abstract_poster').html(poster);
            }else{
                $('#abstract_poster').html("");
            }

            if($('#talk_yes').is(':checked')){
                var talk = 
                    '<div class="card ">'+
                        '<div class="card-header card-header-info">'+
                            '<h4 class="card-title"><?php echo e(__("Abstract For Talk")); ?>'+
                                    '<button type="button" id="talk_button" onclick="clickittalk();" <?php if($user->abstract != null): ?> style="display:none;" <?php endif; ?>  class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-upload" aria-hidden="true"></i></button>'+
                                    '<a href="<?php if($user->abstract != null and $user->abstract->talk != null): ?>'+
                                            '<?php echo e(asset($user->abstract->talk)); ?> '+
                                        '<?php else: ?> '+
                                            '<?php echo e(asset(Settings::first()->abstract)); ?>'+
                                        '<?php endif; ?>" download   class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-download" aria-hidden="true"></i></a>'+
                            '</h4>'+
                            '<p class="card-category"></p>'+
                        '</div>'+
                        '<div class="card-body">'+
                            '<iframe src="'+
                                '<?php if($user->abstract != null and $user->abstract->talk != null): ?>'+
                                    '<?php echo e(asset(explode(".",$user->abstract->talk)[0]."html")); ?>'+
                                '<?php else: ?> '+
                                '<?php echo e(asset(explode(".",Settings::first()->abstract)[0]."html")); ?>'+
                                '<?php endif; ?>" frameborder="0" style="width:100%;height:500px;">'+
                            '</iframe>'+
                        '</div>'+
                        '<input type="file" name="talk" accept=".doc,.docx" id="talk" style="display:none";>'+
                    '</div>';
                $('#abstract_talk').html(talk);
            }else{
                $('#abstract_talk').html("");
            }

        <?php if($user->abstract == null): ?>
            if($('#poster_yes').is(':checked') && $('#talk_yes').is(':checked')){
                var data =  
                    '<div class="row">'+
                        '<label class="col-sm-4 col-form-label"><?php echo e(__("Do You Want To Submit Same Abstract For Both ?")); ?></label>'+
                        '<div class="col-sm-4">'+
                            '<input type="radio" name="same" value="same_Yes" id="same_yes" onclick="checkSame();"  required> Yes'+
                            '<input type="radio" name="same" value="same_No" id="same_no" onclick="checkSame();" checked  required> No'+
                        '</div>'+
                    '</div>';
                $('#same').html(data);
            }
            else{
                $('#same').html('');
            }
        <?php endif; ?>
            
        }
    </script>

    <script>
        function checkSame(){
            if($('#same_yes').is(':checked')){
                $('#abstract_talk').html("");
                $('#abstract_poster').html("");
                var same = 
                    '<div class="card ">'+
                        '<div class="card-header card-header-info">'+
                            '<h4 class="card-title"><?php echo e(__("Abstract For Poster & Talk")); ?>'+
                                    '<button type="button" id="same_button" onclick="clickitsame();" <?php if($user->abstract != null): ?> style="display:none;" <?php endif; ?> class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-upload" aria-hidden="true"></i></button>'+
                                    '<a href="<?php if($user->abstract != null and $user->abstract->same != null): ?>'+
                                            '<?php echo e(asset($user->abstract->same)); ?> '+
                                        '<?php else: ?> '+
                                            '<?php echo e(asset(Settings::first()->abstract)); ?>'+
                                        '<?php endif; ?>" download   class="btn btn-sm btn-rounded btn-info pull-right"><i class="fa fa-download" aria-hidden="true"></i></a>'+
                            '</h4>'+
                            '<p class="card-category"></p>'+
                        '</div>'+
                        '<div class="card-body">'+
                            '<iframe src="'+
                                '<?php if($user->abstract != null and $user->abstract->same != null): ?>'+
                                    '<?php echo e(asset(explode(".",$user->abstract->same)[0]."html")); ?>'+
                                '<?php else: ?> '+
                                    '<?php echo e(asset(explode(".",Settings::first()->abstract)[0]."html")); ?>'+
                                '<?php endif; ?>" frameborder="0" style="width:100%;height:500px;">'+
                            '</iframe>'+
                        '</div>'+
                        '<input type="file" name="same" accept=".doc,.docx" id="same_b" style="display:none";>'+
                    '</div>';
                $('#same_abstract').html(same);
            }
            if($('#same_no').is(':checked')){
                check();
                $('#same_abstract').html('');
            }
        }
    </script>

    <script>
        window.onload=function(){
            check();
            checkSame();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Abstract', 'titlePage' => 'Abstract'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/process/abstract.blade.php ENDPATH**/ ?>