<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <form method="post" action="<?php echo e(route('accomodation.submit',$user)); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            
            <div class="card ">
                <div class="card-header card-header-danger">
                    <h4 class="card-title"><?php echo e(__('Accomodation')); ?><?php if($user->accomodation != null and $user->accomodation->approved and $user->accomodation->cancellation_remarks == null): ?> <span class="pull-right"><a href="#" data-toggle="modal" data-target="#cancel">Request Cancellation</a></span> <?php endif; ?></h4>
                    <p class="card-category"></p>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            
                    <?php if($user->accomodation == null): ?>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Accomodation')); ?></label>
                        <div class="col-sm-10">
                            <input type="radio" id="yes" name="accomodation" value="yes" >Yes
                            <input type="radio" id="no" name="accomodation" value="no" checked>No
                        </div>
                    </div>
                    <?php endif; ?>
                    <br><br>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Category')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('category') ? ' has-danger' : ''); ?>">
                                <select name="category" class="form-control toggle" style="color:black" required id="input-category" disabled>
                                    <option value="">Select Category</option>
                                    <option value="Student/Post Doc" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Student/Post Doc')? 'selected': ' '); ?> <?php endif; ?>>Student/Post Doc</option>
                                    <option value="Faculty" <?php if($user->accomodation != null): ?> <?php echo e(($user->accomodation->category == 'Faculty')? 'selected': ' '); ?> <?php endif; ?>>Faculty</option>
                                </select>
                            
                                <?php if($errors->has('accompanied_person')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('category')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Accomodation For')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="number" class="form-control toggle" name="accomodation_for" id="accomodation_for" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_for); ?>"   <?php else: ?> disabled value="<?php echo e(old('accomodation_for')); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Accomodation Charges')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="number" class="form-control toggle" name="accomodation_charges" id="accomodation_charges" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->accomodation_charges); ?>"   <?php else: ?> disabled value="<?php echo e(old('accomodation_charges')); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-6 col-form-label"><b><?php echo e(__('Deposit Accomodation Charges On Below Mentioned Bank Account:')); ?></b></label><br>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Bank')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->bank); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Account No.')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->account_no); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('IFSC Code')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input type="text" class="form-control" disabled <?php if(App\Settings::first() != null): ?> value="<?php echo e(App\Settings::first()->IFSC); ?>" <?php endif; ?>>
                            </div>
                        </div>
                    </div>
                    <?php if($user->accomodation != null and $user->accomodation->Room_no != null): ?>
                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Room No:')); ?></label>
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <input class="form-control toggle" name="room_no"  type="text" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->Room_no); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Address:')); ?></label>
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <input class="form-control toggle  name="address"  type="text" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->Address); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    </div>
                    <div class="col-md-3">
                        <?php if($user->accomodation!= null and $user->accomodation->approved ): ?>
                            <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                        <?php endif; ?>
                    </div>
                </div>
                </div>
                
            </div>
            
            <div class="card ">
                <div class="card-header card-header-danger">
                    <h4 class="card-title"><?php echo e(__('Accomodation Charges Details')); ?></h4>
                    <p class="card-category"></p>
                </div>
                <div class="card-body">
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Bank Name')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('bank_name') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('bank_name') ? ' is-invalid' : ''); ?>" name="bank_name" id="input-bank_name" type="text" placeholder="<?php echo e(__('Bank Name')); ?>" <?php if($user->accomodation != null): ?>   value="<?php echo e($user->accomodation->bank_name); ?>"   <?php else: ?> disabled value="<?php echo e(old('bank_name')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('bank_name')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('bank_name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Amount')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                <input class="form-control  <?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" name="amount" id="input-amount" type="text" placeholder="<?php echo e(__('Amount')); ?>" readonly <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->amount); ?>"   <?php else: ?>  value="<?php echo e(old('amount')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('amount')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('amount')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Transaction Id:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('transaction_id') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('transaction_id') ? ' is-invalid' : ''); ?>" name="transaction_id" id="input-transaction_id" type="text" placeholder="<?php echo e(__('Transaction Id')); ?>" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->transaction_id); ?>"   <?php else: ?> disabled value="<?php echo e(old('transaction_id')); ?>" <?php endif; ?> required="true" aria-required="true"/ >
                                <?php if($errors->has('transaction_id')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('transaction_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label"><?php echo e(__('Date Of Payment:')); ?></label>
                        <div class="col-sm-10">
                            <div class="form-group<?php echo e($errors->has('payment_date') ? ' has-danger' : ''); ?>">
                                <input class="form-control toggle <?php echo e($errors->has('payment_date') ? ' is-invalid' : ''); ?>" name="payment_date" id="input-payment_date" type="date" placeholder="<?php echo e(__('Payment Date')); ?>" <?php if($user->accomodation != null): ?>  value="<?php echo e($user->accomodation->payment_date); ?>"   <?php else: ?> disabled value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>" <?php endif; ?>  required="true" aria-required="true"/ >
                                <?php if($errors->has('payment_date')): ?>
                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('payment_date')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
                <?php if($user->accomodation == null and $user->details != null): ?>
                    <div class="card-footer ml-auto mr-auto">
                        <button type="submit" class="btn btn-info toggle " disabled><?php echo e(__('Submit')); ?></button>
                    </div>
                <?php endif; ?>
            </div>
          <?php if($user->accomodation!= null and $user->accomodation->cancellation_remarks != null): ?>
          <div class="card ">
                <div class="card-header card-header-warning">
                    <h4 class="card-title"><?php echo e(__('Requested Cancellation')); ?></h4>
                    <p class="card-category"></p>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="row">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Remarks:')); ?></label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                            <textarea name="remarks" id="" placeholder="Enter Remarks..." class="form-control"  style="height:120px !important;border:1px solid #ddd;padding:10px;"><?php echo e($user->accomodation->cancellation_remarks); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-md-3">
                        <?php if($user->accomodation!= null and $user->accomodation->cancellation_approved ): ?>
                            <img src="<?php echo e(asset('/material/img/approved.png')); ?>" alt="ff" style="width:150px;margin-top:100px;">
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="cancel">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Cancellation</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form  action="<?php echo e(route('request.cancellation',$user)); ?>" method="post" id="my-form" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                <!-- Modal body -->
                <div class="modal-body">
                    <textarea name="remarks" id="" placeholder="Enter Remarks..." class="form-control"  style="height:120px !important;border:1px solid #ddd;padding:10px;"></textarea>
                    <button type="submit" class="btn btn-sm btn-info"><?php echo e(__('Submit')); ?></button>
                </div>
            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    $(document).ready(function() {
    $("#yes").click(function () {
        console.log('shiva');
        
        $('.toggle').removeAttr("disabled");
    });

    $("#no").click(function () {
        $('.toggle').attr("disabled",'disabled');
    })
});
</script>
<script>
window.onload = function(){
        <?php if($user->accomodation != null): ?>
            <?php if($user->accomodation->approved): ?>
                $('input').attr('disabled','disabled');
                var elements = document.getElementsByTagName('input');
    
                for (var i = 0, element; element = elements[i++];) {
                    if (element.type === "hidden")
                    element.removeAttribute('disabled');
                    
                }
            <?php endif; ?>
        <?php endif; ?>
        };
</script>

<script>
<?php if(!Auth::user()->admin): ?>
    setInterval(function(){ 
        var category = document.getElementById('input-category').value;
        var accomodation_for = document.getElementById('accomodation_for').value;
        
            if (category == 'Student/Post Doc') {
                console.log(accomodation_for);
                
                var accomodation_fee = <?php echo e($accomodation_fee_student); ?>;
                var accomodation_charges = accomodation_for * accomodation_fee;
                $('#accomodation_charges').val(accomodation_charges);
                $('#input-amount').val(accomodation_charges);
            }
            if (category == 'Faculty') {
                var accomodation_fee = <?php echo e($accomodation_fee_faculty); ?>;
                var accomodation_charges = accomodation_for * accomodation_fee;
                $('#accomodation_charges').val(accomodation_charges);
                $('#input-amount').val(accomodation_charges);
            }
    
    }, 1000);
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Accomodation', 'titlePage' => 'Accomodation '.'('.$user->name.')'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IISER\resources\views/registration/accomodation.blade.php ENDPATH**/ ?>