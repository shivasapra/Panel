<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcFeeSet extends Model
{
    protected $table = 'ac_fee_sets';
}
